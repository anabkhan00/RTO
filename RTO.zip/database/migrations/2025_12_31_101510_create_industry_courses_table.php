<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('industry_courses', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('industry_id');
            $table->unsignedBigInteger('course_id');
            $table->timestamps();
            
            $table->foreign('industry_id')->references('id')->on('industries')->onDelete('cascade');
            $table->foreign('course_id')->references('id')->on('courses')->onDelete('cascade');
            $table->unique(['industry_id', 'course_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('industry_courses');
    }
};