@extends('admin.master_layout.index')
@section('page-title', 'Student Profile')

@section('title', 'Student Profile - ' . $student->name)

@section('content')
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">Details of {{ $student->name }}</h2>
            </div>
            <a href="{{ route('admin.students') }}"
                class="bg-gray-500 text-white font-medium text-xs px-3 py-1.5 rounded-md hover:bg-gray-600 transition-colors">
                <i class="bi bi-arrow-left mr-1"></i> Back to Students
            </a>
        </div>

        <!-- Student Update Section -->
        <div class="mb-8">
            {{-- <h3 class="text-lg font-medium text-brand mb-4">Student Information</h3> --}}

            @php
                $isAdmin = auth()->user()->hasRole('admin');

                $readOnlyAttr = $isAdmin ? '' : 'readonly';
                $disabledAttr = $isAdmin ? '' : 'disabled';

                $readOnlyClass = $isAdmin
                    ? ''
                    : 'bg-gray-100 text-gray-500 cursor-not-allowed focus:ring-0 focus:border-gray-300';
            @endphp

            <form action="{{ route('admin.students.update', $student->id) }}" method="POST" enctype="multipart/form-data"
                class="bg-white rounded-lg border p-6 shadow-sm">
                @csrf
                @method('PUT')

                <div class="grid grid-cols-12 gap-6">

                    <!-- Student Info -->
                    <div class="col-span-12 lg:col-span-8">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <!-- Name -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-person mr-1 text-brand"></i> Name
                                </label>
                                <input type="text" name="name" value="{{ old('name', $student->name) }}" required
                                    {{ $readOnlyAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>

                            <!-- Email -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-envelope mr-1 text-blue-600"></i> Email
                                </label>
                                <input type="email" name="email" value="{{ old('email', $student->email) }}" required
                                    {{ $readOnlyAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>

                            <!-- Phone -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-phone mr-1 text-emerald-600"></i> Phone
                                </label>
                                <input type="text" name="phone" value="{{ old('phone', $student->phone) }}"
                                    {{ $readOnlyAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>

                            <!-- Emergency Contact -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-telephone mr-1 text-rose-600"></i> Emergency Contact No
                                </label>
                                <input type="text" name="emergency_contact" {{ $readOnlyAttr }}
                                    value="{{ old('emergency_contact', $student->studentDetail->emergency_contact ?? '') }}"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
               focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>

                            <!-- Placement Hours -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-clock mr-1 text-amber-600"></i> Placement Hours
                                </label>
                                <input type="number" name="placement_hours" {{ $readOnlyAttr }}
                                    value="{{ old('placement_hours', $student->studentDetail->placement_hours ?? '') }}"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm
               focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>


                            <!-- RTO -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-building mr-1"></i> RTO
                                </label>
                                <select name="rto_id" id="studentRto" {{ $disabledAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white {{ $readOnlyClass }}">
                                    <option value="">Select RTO</option>
                                    @foreach ($rtos as $rto)
                                        <option value="{{ $rto->id }}"
                                            {{ old('rto_id', $studentRtoId) == $rto->id ? 'selected' : '' }}>
                                            {{ $rto->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @if (!$isAdmin)
                                    <input type="hidden" name="rto_id" value="{{ old('rto_id', $studentRtoId) }}">
                                @endif
                            </div>


                            <!-- Priority -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2"><i class="bi bi-flag mr-1"></i>
                                    Priority</label>
                                <select name="priority" {{ $disabledAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white {{ $readOnlyClass }}">
                                    <option value="">Select Priority</option>
                                    <option value="high_priority"
                                        {{ old('priority', $student->studentDetail->priority ?? '') == 'high_priority' ? 'selected' : '' }}>
                                        High Priority</option>
                                    <option value="medium_priority"
                                        {{ old('priority', $student->studentDetail->priority ?? '') == 'medium_priority' ? 'selected' : '' }}>
                                        Medium Priority</option>
                                    <option value="low_priority"
                                        {{ old('priority', $student->studentDetail->priority ?? '') == 'low_priority' ? 'selected' : '' }}>
                                        Low Priority</option>
                                </select>
                            </div>

                            <!-- Course -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-book mr-1 text-indigo-600"></i> Course
                                </label>
                                <select name="course_id" {{ $disabledAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white {{ $readOnlyClass }}">
                                    <option value="">Select Course</option>
                                    @foreach ($courses as $course)
                                        <option value="{{ $course->id }}"
                                            {{ old('course_id', $student->course_id) == $course->id ? 'selected' : '' }}>
                                            {{ $course->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @if (!$isAdmin)
                                    <input type="hidden" name="course_id"
                                        value="{{ old('course_id', $student->course_id) }}">
                                @endif
                            </div>

                            <!-- Industry -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2"><i class="bi bi-book mr-1"></i>
                                    Industry</label>
                                <select name="industry_id" {{ $disabledAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white {{ $readOnlyClass }}">
                                    <option value="">Select Industry</option>
                                    @foreach ($industries as $industry)
                                        <option value="{{ $industry->id }}"
                                            {{ old('industry_id', $student->studentDetail->industry_id ?? '') == $industry->id ? 'selected' : '' }}>
                                            {{ $industry->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @if (!$isAdmin)
                                    <input type="hidden" name="industry_id"
                                        value="{{ old('industry_id', $student->studentDetail->industry_id ?? '') }}">
                                @endif
                            </div>

                            <!-- Progress Status -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2"><i
                                        class="bi bi-clipboard-check mr-1"></i> Progress Status</label>
                                <select name="progress_status"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white">
                                    <option value="awaiting_placements"
                                        {{ old('progress_status', $student->studentDetail->progress_status ?? '') == 'awaiting_placements' ? 'selected' : '' }}>
                                        Awaiting Placements</option>
                                    <option value="booked_placements"
                                        {{ old('progress_status', $student->studentDetail->progress_status ?? '') == 'booked_placements' ? 'selected' : '' }}>
                                        Booked Placements</option>
                                    <option value="active_placements"
                                        {{ old('progress_status', $student->studentDetail->progress_status ?? '') == 'active_placements' ? 'selected' : '' }}>
                                        Active Placements</option>
                                    <option value="completed_placements"
                                        {{ old('progress_status', $student->studentDetail->progress_status ?? '') == 'completed_placements' ? 'selected' : '' }}>
                                        Completed Placements</option>
                                    <option value="flagged_placements"
                                        {{ old('progress_status', $student->studentDetail->progress_status ?? '') == 'flagged_placements' ? 'selected' : '' }}>
                                        Flagged Placements</option>
                                </select>
                            </div>

                            <!-- Student Status -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2"><i
                                        class="bi bi-person-check mr-1"></i> Student Status</label>
                                <select name="student_status"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white">
                                    <option value="active"
                                        {{ old('student_status', $student->studentDetail->student_status ?? 'active') == 'active' ? 'selected' : '' }}>
                                        Active</option>
                                    <option value="inactive"
                                        {{ old('student_status', $student->studentDetail->student_status ?? '') == 'inactive' ? 'selected' : '' }}>
                                        Inactive</option>
                                    <option value="blocked"
                                        {{ old('student_status', $student->studentDetail->student_status ?? '') == 'blocked' ? 'selected' : '' }}>
                                        Blocked</option>
                                </select>
                            </div>

                            <!-- Address -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-geo-alt mr-1 text-rose-600"></i> Address
                                </label>
                                <input type="text" name="address" id="addressInput" {{ $readOnlyAttr }}
                                    value="{{ old('address', $student->address) }}" required
                                    placeholder="Start typing address..."
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                                <input type="hidden" name="latitude" id="latitudeInput"
                                    value="{{ old('latitude', $student->latitude) }}">
                                <input type="hidden" name="longitude" id="longitudeInput"
                                    value="{{ old('longitude', $student->longitude) }}">
                            </div>

                            <!-- Gender -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-gender-ambiguous mr-1 text-purple-600"></i> Gender
                                </label>
                                <select name="gender" {{ $disabledAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white {{ $readOnlyClass }}">
                                    <option value="">Select Gender</option>
                                    <option value="male"
                                        {{ old('gender', $student->studentDetail->gender ?? '') == 'male' ? 'selected' : '' }}>
                                        Male</option>
                                    <option value="female"
                                        {{ old('gender', $student->studentDetail->gender ?? '') == 'female' ? 'selected' : '' }}>
                                        Female</option>
                                    <option value="other"
                                        {{ old('gender', $student->studentDetail->gender ?? '') == 'other' ? 'selected' : '' }}>
                                        Other</option>
                                </select>
                                @if (!$isAdmin)
                                    <input type="hidden" name="gender"
                                        value="{{ old('gender', $student->studentDetail->gender ?? '') }}">
                                @endif
                            </div>

                            <!-- Transport -->
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-truck mr-1 text-cyan-600"></i> Transport
                                </label>
                                <input type="text" name="transport" {{ $readOnlyAttr }}
                                    value="{{ old('transport', $student->studentDetail->transport ?? '') }}"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}" />
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2"><i
                                        class="bi bi-clipboard-check mr-1"></i> Interview Status</label>
                                <select name="interview_status"
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white">
                                    <option value="">Select Interview Status</option>
                                    <option value="scheduled"
                                        {{ old('interview_status') == 'scheduled' ? 'selected' : '' }}>Scheduled</option>
                                    <option value="in_progress"
                                        {{ old('interview_status') == 'in_progress' ? 'selected' : '' }}>In Progress
                                    </option>
                                    <option value="completed"
                                        {{ old('interview_status') == 'completed' ? 'selected' : '' }}>Completed</option>
                                    <option value="no_show" {{ old('interview_status') == 'no_show' ? 'selected' : '' }}>
                                        No Show</option>
                                    <option value="rescheduled"
                                        {{ old('interview_status') == 'rescheduled' ? 'selected' : '' }}>Rescheduled
                                    </option>
                                </select>
                            </div>

                            <!-- Medical Condition -->
                            <div class="md:col-span-3">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-heart-pulse mr-1 text-red-600"></i> Medical Condition
                                </label>
                                <textarea name="medical_condition" rows="2" {{ $readOnlyAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}">{{ old('medical_condition', $student->studentDetail->medical_condition ?? '') }}</textarea>
                            </div>

                            <!-- Placement Data -->
                            <div class="md:col-span-3">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    <i class="bi bi-clipboard-data mr-1 text-gray-600"></i> Placement Data
                                </label>
                                <textarea name="placement_data" rows="2" {{ $readOnlyAttr }}
                                    class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand {{ $readOnlyClass }}">{{ old('placement_data', $student->studentDetail->placement_data ?? '') }}</textarea>
                            </div>
                        </div>
                    </div>
                    <!-- Profile Image -->
                    <div class="col-span-12 lg:col-span-4">
                        <div>
                            <h4 class="text-sm font-medium text-gray-700 mb-3">
                                <i class="bi bi-image mr-1 text-blue-600"></i> Profile Image
                            </h4>
                            <div id="profileDropzone"
                                class="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-brand transition-colors cursor-pointer bg-gray-50 hover:bg-blue-50">
                                <div id="dropzoneContent">
                                    <i class="bi bi-cloud-upload text-5xl text-gray-300 mb-3"></i>
                                    <p class="text-sm text-gray-600 font-medium">Drop image here or click to upload</p>
                                    <p class="text-xs text-gray-500 mt-2">PNG, JPG, GIF up to 5MB</p>
                                </div>
                                <div id="imagePreview" class="{{ $student->profile_image ? '' : 'hidden' }}">
                                    <img id="previewImg" src="{{ $student->profile_image_url ?? '' }}"
                                        class="max-w-full h-48 mx-auto rounded-lg object-cover shadow-sm" />
                                    <button type="button" id="removeImage"
                                        class="mt-3 px-3 py-1 text-xs bg-red-50 text-red-600 hover:bg-red-100 rounded-md transition-colors">
                                        <i class="bi bi-trash mr-1"></i>Remove Image
                                    </button>
                                </div>
                            </div>
                            <input type="file" id="profileImageInput" name="profile_image" accept="image/*"
                                {{ $disabledAttr }} class="hidden" />
                            <p class="text-xs text-gray-400 mt-2">Use high-quality portrait images for best results</p>
                        </div>
                    </div>
                </div>

                <div class="flex justify-between mt-4 items-center"> @php
                    $statusRaw = old('interview_status', $student->studentDetail->interview_status ?? 'pending');
                    $status = ucwords(str_replace('_', ' ', $statusRaw));
                    $statusColors = [
                        'Assigned' => ['bg' => 'bg-gray-50', 'text' => 'text-gray-700', 'border' => 'border-gray-100'],
                        'Scheduled' => [
                            'bg' => 'bg-orange-50',
                            'text' => 'text-orange-700',
                            'border' => 'border-orange-100',
                        ],
                        'In Progress' => [
                            'bg' => 'bg-blue-50',
                            'text' => 'text-blue-700',
                            'border' => 'border-blue-100',
                        ],
                        'Completed' => [
                            'bg' => 'bg-emerald-50',
                            'text' => 'text-emerald-700',
                            'border' => 'border-emerald-100',
                        ],
                        'No Show' => [
                            'bg' => 'bg-red-50',
                            'text' => 'text-red-700',
                            'border' => 'border-red-100',
                        ],
                        'Rescheduled' => [
                            'bg' => 'bg-indigo-50',
                            'text' => 'text-indigo-700',
                            'border' => 'border-indigo-100',
                        ],
                    ];
                    $colors = $statusColors[$status] ?? $statusColors['Assigned'];
                @endphp <span
                        class="inline-flex items-center px-4 py-2 text-sm font-semibold rounded-full {{ $colors['bg'] }} {{ $colors['text'] }} {{ $colors['border'] }} border shadow">
                        {{ $status }} </span>
                    <div class="flex gap-2">
                        <button type="submit"
                            class="bg-emerald-600 text-white text-xs px-3 py-1.5 rounded-md hover:bg-emerald-700 transition-colors font-medium">
                            Update
                        </button>
                        <button type="reset"
                            class="bg-red-600 text-white text-xs px-3 py-1.5 rounded-md hover:bg-red-700 transition-colors font-medium">
                            Cancel
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <div class="mb-8">
            <h3 class="text-lg font-medium text-brand mb-4 flex items-center gap-2">
                <i class="bi bi-sticky text-amber-600"></i> Notes
            </h3>
            <div class="location-tab-content block bg-white rounded-lg border shadow-sm p-4">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
                    <!-- All Notes Display -->
                    <div class="lg:col-span-2">
                        <h4 class="text-sm font-medium text-gray-700 mb-3">All Notes</h4>
                        <div class="bg-gray-50 rounded-lg border border-gray-200 p-4 min-h-32 max-h-64 overflow-y-auto space-y-3"
                            id="allNotesDisplay">
                            @if (count($notes) > 0)
                                @foreach ($notes as $note)
                                    @php
                                        $roleColors = [
                                            'admin' => 'bg-red-50 border-red-200 text-red-800',
                                            'rto' => 'bg-blue-50 border-blue-200 text-blue-800',
                                            'coordinator' => 'bg-green-50 border-green-200 text-green-800',
                                        ];
                                        $roleColor =
                                            $roleColors[$note->author_role] ??
                                            'bg-gray-50 border-gray-200 text-gray-800';
                                    @endphp
                                    <div class="p-3 rounded-lg border {{ $roleColor }}"
                                        data-note-id="{{ $note->id }}">
                                        <div class="flex justify-between items-start mb-2">
                                            <span
                                                class="text-xs font-medium uppercase tracking-wide flex items-center gap-1">
                                                <i class="bi bi-person-badge"></i>
                                                {{ ucfirst(str_replace('_', ' ', $note->author_role)) }}
                                            </span>
                                            <div class="flex items-center gap-2 text-xs opacity-75">
                                                <span>{{ $note->created_at->format('M j, Y') }}</span>
                                                @if ($note->author_id === auth()->id())
                                                    <button type="button"
                                                        class="note-edit-btn text-blue-600 hover:text-blue-800"
                                                        data-note-id="{{ $note->id }}">
                                                        <i class="bi bi-pencil"></i>
                                                    </button>
                                                @endif
                                            </div>
                                        </div>
                                        <p class="text-sm note-content">{{ $note->content }}</p>
                                    </div>
                                @endforeach
                            @else
                                <div class="text-center py-8">
                                    <i class="bi bi-sticky text-2xl text-gray-300 mb-2"></i>
                                    <p class="text-gray-400 italic text-sm">No notes added yet</p>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Add Notes Form -->
                    <div class="flex flex-col h-full">
                        <h4 class="text-sm font-medium text-gray-700 mb-3">Add Note</h4>

                        <form id="notesForm" class="flex-grow">
                            @csrf
                            <textarea name="content" placeholder="Add a note about this student..."
                                class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand"
                                rows="4" required></textarea>
                            @can('students.edit')
                                <button type="submit"
                                    class="bg-brand text-white text-xs px-3 py-1.5 mt-3 rounded-md hover:bg-gold transition-colors font-medium">
                                    Save
                                </button>
                            @endcan
                        </form>

                        <!-- Role Legend -->
                        <div class="mt-4 p-3 bg-gray-50 rounded-lg">
                            <h5 class="text-xs font-medium text-gray-700 mb-2">Note Colors:</h5>
                            <div class="space-y-1 text-xs">
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 bg-red-100 border border-red-200 rounded"></div>
                                    <span>Admin</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 bg-blue-100 border border-blue-200 rounded"></div>
                                    <span>RTO</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="w-3 h-3 bg-green-100 border border-green-200 rounded"></div>
                                    <span>Coordinator</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <!-- Map & Notes Section -->
        <div class="mb-8">
            <h3 class="text-lg font-medium text-brand mb-4 flex items-center gap-2">
                <i class="bi bi-geo-alt text-emerald-600"></i> Industries Within 20km Radius
            </h3>
            <div class="location-tab-content block bg-white rounded-lg border shadow-sm p-4">
                <div id="industryMap" class="w-full h-[420px] rounded-xl shadow-lg border border-gray-200"></div>
                {{-- <div class="mt-3 flex items-center justify-between">
                    <p class="text-xs text-gray-500">Industries available within 20 km radius of student location</p>
                    <div class="flex items-center text-xs text-gray-600">
                        <div class="w-3 h-3 bg-blue-200 border border-blue-400 rounded-full mr-2"></div>
                        <span>20km Coverage Area</span>
                    </div>
                </div> --}}
            </div>
        </div>

        <!-- Interview Links Section -->
        <div class="mb-8" id="interviewScheduleSection">
            <h3 class="text-lg font-medium text-brand mb-4 flex items-center gap-2">
                <i class="bi bi-calendar2-week text-indigo-600"></i> Interview Schedule
            </h3>
            <div class="bg-white rounded-lg border shadow-sm p-4">
                <form action="{{ route('admin.student-documents.interviews.store', $student->id) }}" method="POST"
                    class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end mb-6">
                    @csrf
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Industry</label>
                        <select name="industry_id" id="interviewIndustrySelect" required
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white">
                            <option value="">Select Industry</option>
                            @foreach ($industries as $industry)
                                <option value="{{ $industry->id }}">{{ $industry->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Interview Date & Time</label>
                        <input type="datetime-local" name="interview_at"
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand" />
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select name="status"
                            class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand bg-white">
                            <option value="">Select Status</option>
                            <option value="scheduled">Scheduled</option>
                            <option value="in_progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="no_show">No Show</option>
                            <option value="rescheduled">Rescheduled</option>
                        </select>
                    </div>

                    <div class="flex gap-2">
                        <button type="submit"
                            class="bg-emerald-600 text-white text-xs px-4 py-2 rounded-md hover:bg-emerald-700 transition-colors font-medium">
                            Update
                        </button>
                        <button type="reset"
                            class="bg-red-600 text-white text-xs px-4 py-2 rounded-md hover:bg-red-700 transition-colors font-medium">
                            Cancel
                        </button>
                    </div>
                </form>

                <div>
                    <table class="min-w-full text-sm">
                        <thead>
                            <tr class="text-left text-gray-600 border-b">
                                <th class="py-2 pr-4">Industry</th>
                                <th class="py-2 pr-4">Interview At</th>
                                <th class="py-2 pr-4">Status</th>
                                <th class="py-2 pr-4">Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($interviews as $interview)
                                <tr class="border-b text-gray-700">
                                    <td class="py-2 pr-4">{{ $interview->industry->name ?? 'N/A' }}</td>
                                    <td class="py-2 pr-4">
                                        {{ $interview->interview_at ? \Carbon\Carbon::parse($interview->interview_at)->format('j M Y, g:i A') : '—' }}
                                    </td>
                                    <td class="py-2 pr-4">
                                        {{ $interview->status ? str_replace('_', ' ', ucfirst($interview->status)) : '—' }}
                                    </td>
                                    <td class="py-2 pr-4">{{ $interview->created_at->format('j M Y') }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td class="py-3 text-gray-500" colspan="4">No interview links yet.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Document Management Section (Checklist & Upload) -->
        <div id="document-section" class="mb-8">
            <h3 class="text-lg font-medium text-brand mb-4 flex items-center gap-2">
                <i class="bi bi-folder2-open text-amber-600"></i> Student Profile
            </h3>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Checklist Status Card -->
                <div class="bg-white rounded-lg border shadow-sm">
                    <div class="p-4 border-b">
                        <h3 class="text-lg font-medium text-brand flex items-center">
                            <i class="bi bi-list-check mr-2 text-emerald-600"></i>Document Checklist
                        </h3>
                        <p class="text-sm text-gray-600 mt-1">
                            {{ $checklists ? $checklists->count() : 0 }} required documents
                        </p>

                    </div>
                    @if ($checklists)
                        <div class="p-4 max-h-96 overflow-y-auto">
                            <div class="space-y-2">
                                @foreach ($checklists as $checklist)
                                    @php
                                        $documents = $student->studentDocuments->filter(function ($doc) use (
                                            $checklist,
                                        ) {
                                            return $doc->checklist_ids && in_array($checklist->id, $doc->checklist_ids);
                                        });
                                        $hasDocument = $documents->count() > 0;
                                    @endphp

                                    <div class="rounded hover:bg-gray-50">
                                        <div class="flex items-center justify-between">
                                            <div class="flex items-center gap-2">
                                                @if ($hasDocument)
                                                    <i class="bi bi-check-circle-fill text-green-500 text-sm"></i>
                                                @else
                                                    <i class="bi bi-circle text-gray-400 text-sm"></i>
                                                @endif

                                                <span
                                                    class="text-sm {{ $hasDocument ? 'text-green-700 font-medium' : 'text-gray-700' }}">
                                                    {{ $checklist->name }}
                                                </span>
                                            </div>

                                            @if ($hasDocument)
                                                <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                                                    {{ $documents->count() }}
                                                </span>
                                            @endif
                                        </div>

                                        @if ($hasDocument)
                                            <div class="mt-2 ml-6 space-y-1">
                                                @foreach ($documents as $document)
                                                    <div
                                                        class="flex items-center justify-between text-xs bg-gray-50 p-2 rounded">
                                                        <span class="text-gray-600 truncate">{{ $document->label }}</span>
                                                        <div class="flex gap-2">
                                                            <a href="{{ asset('storage/' . $document->file_path) }}"
                                                                target="_blank">
                                                                <i class="bi bi-eye"></i>
                                                            </a>
                                                            <a href="{{ asset('storage/' . $document->file_path) }}"
                                                                download>
                                                                <i class="bi bi-download"></i>
                                                            </a>
                                                            @can('documents.delete')
                                                                <button class="delete-document"
                                                                    data-id="{{ $document->id }}">
                                                                    <i class="bi bi-trash"></i>
                                                                </button>
                                                            @endcan
                                                        </div>
                                                    </div>
                                                @endforeach
                                            </div>
                                        @endif
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    @else
                        <p class="text-sm text-gray-500 p-4">No document checklist assigned to this course.</p>
                    @endif

                </div>

                <!-- Upload Documents Card -->
                <div class="bg-white rounded-lg border shadow-sm">
                    <div class="p-4 border-b">
                        <h3 class="text-lg font-medium text-brand flex items-center">
                            <i class="bi bi-cloud-upload mr-2 text-blue-600"></i>Upload Documents
                        </h3>
                        <p class="text-sm text-gray-600 mt-1">Upload multiple files (Max 50MB each)</p>
                    </div>
                    <div class="p-4">
                        @can('documents.upload')
                            <form id="studentDocumentsUploadForm"
                                action="{{ route('admin.student-documents.store', $student->id) }}" method="POST"
                                enctype="multipart/form-data" class="space-y-4">
                                @csrf

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Document Label</label>
                                    <input type="text" name="label" placeholder="Enter document label" required
                                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand" />
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Select Files</label>
                                    <input type="file" name="files[]" multiple
                                        accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.zip" required
                                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand" />
                                    <p class="text-xs text-gray-500 mt-1">Supported: PDF, DOC, DOCX, JPG, PNG, ZIP</p>
                                </div>

                                <div class="pt-2 flex">
                                    <button type="submit" id="uploadBtn"
                                        class="bg-brand text-white text-xs px-3 py-1.5 rounded-md hover:bg-gold transition-colors font-medium">
                                        <span id="uploadText"><i class="bi bi-upload mr-2"></i>Upload Documents</span>
                                        <span id="uploadLoader" class="hidden">
                                            <i class="bi bi-arrow-clockwise animate-spin mr-2"></i>Uploading...
                                        </span>
                                    </button>
                                </div>
                            </form>
                        @endcan
                    </div>
                </div>
            </div>
        </div>

        <!-- Student Availability Section (FullCalendar) -->
        <div class="mb-8">
            <h3 class="text-lg font-medium text-green-700 mb-4 flex items-center gap-2">
                <i class="bi bi-calendar-event text-green-600"></i> Student Schedule
            </h3>

            <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
                <!-- Calendar Area -->
                <div class="lg:col-span-3">
                    <div class="bg-white rounded-lg border shadow-sm p-4 h-[600px]">
                        <div id="calendar" class="h-full"></div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="lg:col-span-1">
                    <div class="bg-white rounded-lg border shadow-sm p-4 sticky top-6">
                        <h4 class="text-lg font-medium mb-4 text-green-700">Week Summary</h4>

                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Total Hours</label>
                            <div class="text-3xl font-bold text-gray-800" id="totalHoursDisplay">0.0</div>
                            <input type="hidden" id="totalHoursInput">
                        </div>

                        <div class="space-y-3">
                            <button id="saveBtn"
                                class="w-full px-4 py-2 rounded-lg bg-emerald-600 text-white font-medium flex justify-center items-center gap-2 hover:bg-emerald-700 transition-colors">
                                <i class="fas fa-save"></i> Save Schedule
                            </button>

                            <div class="p-3 bg-blue-50 text-blue-800 rounded-lg text-xs leading-relaxed">
                                <i class="fas fa-info-circle mr-1"></i>
                                <strong>Instructions:</strong><br>
                                Click & Drag to create a slot.<br>
                                Click a slot to delete it.<br>
                                Resize/Move slots freely.<br>
                                Don't forget to Save!
                            </div>
                        </div>

                        <div class="mt-6 border-t pt-4">
                            <h5 class="text-sm font-medium text-gray-700 mb-2">Selected Ranges</h5>
                            <div id="eventList" class="text-xs text-gray-600 space-y-1 max-h-60 overflow-y-auto">
                                <!-- Dynamic list -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Appointment Modal -->
    <div id="appointmentModal" class="fixed inset-0 bg-black/50 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-md rounded-xl shadow-2xl p-6 relative">
            <button onclick="closeAppointmentModal()"
                class="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl">
                &times;
            </button>
            <h3 class="text-xl font-semibold text-brand mb-4" id="appointmentModalTitle">Add Appointment</h3>
            <form id="appointmentForm">
                <input type="hidden" id="appointmentId">
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Title</label>
                    <input type="text" id="appointmentTitle" required
                        class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-1 focus:ring-brand focus:border-brand">
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date</label>
                    <input type="date" id="appointmentDate" required
                        class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-1 focus:ring-brand focus:border-brand">
                </div>
                <div class="mb-3">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Time</label>
                    <input type="time" id="appointmentTime" required
                        class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-1 focus:ring-brand focus:border-brand">
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                    <textarea id="appointmentNotes" rows="3"
                        class="w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:ring-1 focus:ring-brand focus:border-brand"></textarea>
                </div>
                <div class="flex gap-3">
                    <button type="submit"
                        class="bg-brand text-white px-4 py-2 rounded-md hover:bg-gold transition-colors text-sm">
                        Save
                    </button>
                    <button type="button" onclick="closeAppointmentModal()"
                        class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 transition-colors text-sm">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>



    <!-- Checklist Modal -->
    <div id="checklistModal" class="fixed inset-0 bg-black/50 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg rounded-xl shadow-2xl p-6 relative">
            <button id="closeChecklistModal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl">
                &times;
            </button>

            <h3 class="text-xl font-semibold text-brand mb-4">Select Document Types</h3>

            <form id="checklistForm" method="POST">
                @csrf
                <input type="hidden" id="uploadedDocuments" name="document_ids" value="">

                <div class="space-y-3 mb-6">
                    @if ($checklists)
                        @foreach ($checklists as $checklist)
                            <label class="flex items-center">
                                <input type="checkbox" name="checklist_ids[]" value="{{ $checklist->id }}"
                                    class="mr-3">
                                <span class="text-sm">{{ $checklist->name }}</span>
                            </label>
                        @endforeach
                    @else
                        <p class="text-sm text-gray-500">No checklists available.</p>
                    @endif

                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" id="skipChecklist"
                        class="bg-gray-500 text-white text-xs px-3 py-1.5 rounded-md hover:bg-gray-600 font-medium">
                        Skip
                    </button>
                    <button type="submit"
                        class="bg-brand text-white text-xs px-3 py-1.5 rounded-md hover:bg-gold font-medium">
                        Save Types
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Note Modal -->
    <div id="editNoteModal" class="fixed inset-0 bg-black/50 flex justify-center items-center hidden z-50">
        <div class="bg-white w-full max-w-lg rounded-xl shadow-2xl p-6 relative">
            <button id="closeEditNoteModal" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-2xl">
                &times;
            </button>

            <h3 class="text-xl font-semibold text-brand mb-4">Edit Note</h3>

            <form id="editNoteForm" class="space-y-4">
                @csrf
                <input type="hidden" id="editNoteId" value="">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Note</label>
                    <textarea id="editNoteContent" rows="4" required
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-brand focus:border-brand"></textarea>
                </div>
                <div class="flex justify-end gap-3">
                    <button type="button" id="cancelEditNote"
                        class="bg-red-600 text-white text-xs px-3 py-1.5 rounded-md hover:bg-red-700 transition-colors font-medium">
                        Cancel
                    </button>
                    <button type="submit"
                        class="bg-emerald-600 text-white text-xs px-3 py-1.5 rounded-md hover:bg-emerald-700 transition-colors font-medium">
                        Save
                    </button>
                </div>
            </form>
        </div>
    </div>

    @section('right-sidebar')
        <div data-right-sidebar="true" class="h-full flex flex-col">
            <div class="p-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-800">Placement Match</h3>
                <p class="text-xs text-gray-500">Select an industry to verify documents</p>
            </div>
            <div class="p-4 space-y-4 overflow-y-auto">
                <div class="p-3 bg-gray-50 rounded border">
                    <div class="text-xs text-gray-500">Student</div>
                    <div id="matchStudentName" class="text-sm font-medium text-gray-900">{{ $student->name }}</div>
                    <div id="matchCourseName" class="text-xs text-gray-600">
                        {{ $student->course->name ?? 'No Course' }}
                    </div>
                </div>
                <div class="p-3 bg-gray-50 rounded border">
                    <div class="text-xs text-gray-500">Industry</div>
                    <div id="matchIndustryName" class="text-sm font-medium text-gray-900">Not selected</div>
                    <div id="matchIndustryMeta" class="text-xs text-gray-600">Select from map or list</div>
                </div>
                <div>
                    <div class="text-xs font-medium text-gray-600 mb-2">Course Match</div>
                    <div id="matchCourseStatus"
                        class="text-xs inline-flex items-center px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                        Not checked
                    </div>
                </div>
                <div>
                    <div class="text-xs font-medium text-gray-600 mb-2">Course Checklist</div>
                    <div id="matchCourseChecklist" class="space-y-2 text-sm">
                        <div class="text-xs text-gray-400">Select an industry to evaluate.</div>
                    </div>
                </div>
                <div>
                    <div class="text-xs font-medium text-gray-600 mb-2">Industry Checklist</div>
                    <div id="matchIndustryChecklist" class="space-y-2 text-sm">
                        <div class="text-xs text-gray-400">Select an industry to evaluate.</div>
                    </div>
                </div>
                <div>
                    <div class="text-xs font-medium text-gray-600 mb-2">Additional Documents</div>
                    <div id="matchAdditionalDocs" class="space-y-2 text-sm">
                        <div class="text-xs text-gray-400">Select an industry to evaluate.</div>
                    </div>
                </div>
            </div>
            <div class="p-4 border-t border-gray-200 space-y-2">
                <button id="matchScheduleBtn" type="button" disabled
                    class="w-full bg-emerald-600 disabled:bg-gray-300 text-white text-xs px-3 py-2 rounded-md font-medium">
                    Schedule Interview
                </button>
                <button id="matchScrollDocsBtn" type="button"
                    class="w-full bg-gray-100 text-gray-700 text-xs px-3 py-2 rounded-md font-medium">
                    View Documents
                </button>
                <div id="matchStatusNote" class="text-xs text-gray-500">Select an industry to see requirements.</div>
            </div>
        </div>
    @endsection

    @push('styles')
        <link rel="stylesheet" href="{{ asset('/assets/css/admin/student-documents.css') }}">
        <style>
            .fc .fc-toolbar-title {
                font-size: 0.9rem;
                font-weight: 600;
            }
        </style>
    @endpush

    @push('vendor-scripts')
        <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js'></script>
        @include('includes.google-maps', ['callback' => 'initIndustryMap'])
    @endpush

    @push('scripts')
        @php
            $studentMap = [
                'name' => $student->name,
                'lat' => $student->latitude,
                'lng' => $student->longitude,
            ];

            $industryMap = $nearbyIndustries
                ->map(function ($i) {
                    return [
                        'id' => $i->id,
                        'name' => $i->name,
                        'industry_status' => $i->industry_status ?? 'Industry Partner', // or remove if not needed
                        'contact_person' => $i->contact_person,
                        'phone' => $i->phone,
                        'email' => $i->email,
                        'address' => $i->address,
                        'website' => $i->website,
                        'lat' => $i->latitude,
                        'lng' => $i->longitude,
                        'distance' => round($i->distance, 2),
                    ];
                })
                ->values();

            $authUserMap = [
                'id' => auth()->id(),
                'role' => auth()->user()->role,
                'coordinator_type' => auth()->user()->coordinator_type ?? null,
            ];
        @endphp

        <script>
            window.studentId = @json($student->id);
            window.student = @json($studentMap);
            window.industries = @json($industryMap);
            window.authUser = @json($authUserMap);
        </script>

        <script src="{{ asset('/assets/js/admin/student-documents.js') }}"></script>
    @endpush

@endsection
